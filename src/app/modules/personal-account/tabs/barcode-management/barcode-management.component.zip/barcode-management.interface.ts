export interface MeasurementUnit {
  id: string;
  name: string | null;
  shortName: string;
  code: number;
  coef?: number;
  isDeleted?: boolean;
}
export interface ProductBarcode {
  id?: string;
  barCode: string;
  representationFrom1C?: string | null;
  coefficient: number;
  comment?: string;
  productInstanceId: string;
  measurementUnitId: string;
  measurementUnit: any;
  productInstance?: {
    id: string;
    article: string;
    fullName: string;
    productImageLink?: string;
  };
  isDeleted?: boolean;
  createdAt?: string;
  updatedAt?: string;
}

export interface ProductSearchResult {
  id: string;
  article: string;
  fullName: string;
  shortName?: string;
  productImageLink?: string;
  productImageLinks?: string[];
  retailPrice?: number;
  wholesalePrice?: number;
  baseMeasurementUnit?: MeasurementUnit;
  productInstanceId: string;
}

export interface FilterRequest {
  filters: Array<{
    field: string;
    values: string[];
    type: number; // 0 = Contains, 10 = Equal
  }>;
  sorts?: Array<{
    field: string;
    sortType: number; // 1 = Asc, 2 = Desc
  }>;
  page: number;
  pageSize: number;
}

export interface FilterResponse<T> {
  message: string;
  status: number;
  pageCount: number;
  totalCount: number;
  page: number;
  pageSize: number;
  data: T[];
}

