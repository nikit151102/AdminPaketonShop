import { Component, OnInit, OnDestroy, ViewChild, ElementRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { Subject, takeUntil, debounceTime, distinctUntilChanged } from 'rxjs';
import { ProductSearchResult, ProductBarcode, MeasurementUnit } from './barcode-management.interface';
import { BarcodeManagementService } from './barcode-management.service';

type ProductRow = ProductSearchResult & { barcodes: ProductBarcode[]; loadingBarcodes?: boolean; adding?: boolean };

@Component({
  selector: 'app-barcode-management',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule],
  templateUrl: './barcode-management.component.html',
  styleUrls: ['./barcode-management.component.scss']
})
export class BarcodeManagementComponent implements OnInit, OnDestroy {
  @ViewChild('searchInput') searchInput!: ElementRef<HTMLInputElement>;
  searchQuery = '';
  productSearchResults: ProductRow[] = [];
  measurementUnits: MeasurementUnit[] = [];
  totalProductResults = 0;
  currentProductPage = 0;
  totalProductPages = 1;
  isLoadingSearch = false;
  isSaving = false;
  editingBarcode: ProductBarcode | null = null;
  originalBarcode: ProductBarcode | null = null;
  drafts: Record<string, { barCode: string; representationFrom1C: string; coefficient: number; measurementUnitId: string }> = {};
  toastMessage: string | null = null;
  toastType: 'success' | 'error' = 'success';
  private destroy$ = new Subject<void>();
  private searchDebounce = new Subject<string>();

  constructor(private barcodeService: BarcodeManagementService, private fb: FormBuilder) { }

  addBarcodeForm!: FormGroup;

  ngOnInit(): void {


    this.addBarcodeForm = this.fb.group({
      barCode: ['', [Validators.required, Validators.minLength(3)]],
      representationFrom1C: [''],
      coefficient: [1, [Validators.required, Validators.min(0.001)]],
      measurementUnitId: ['', Validators.required],
      comment: ['сайт пакетон']
    });


    this.barcodeService.getCategory().subscribe((values: any) => {
      console.log('values', values)
    })


    this.barcodeService.getMeasurementUnits().pipe(takeUntil(this.destroy$)).subscribe({
      next: units => this.measurementUnits = units,
      error: () => this.showToast('Не удалось загрузить единицы измерения', 'error')
    });
    this.searchDebounce.pipe(debounceTime(500), distinctUntilChanged(), takeUntil(this.destroy$))
      .subscribe(q => { if (q.trim().length >= 2) this.searchProduct(); });
  }
  ngOnDestroy(): void { this.destroy$.next(); this.destroy$.complete(); this.searchDebounce.complete(); }

  onSearchInput(): void { this.searchDebounce.next(this.searchQuery); }
  searchProduct(): void {
    const query = this.searchQuery.trim();
    if (query.length < 2) { this.showToast('Введите минимум 2 символа для поиска', 'error'); return; }
    this.isLoadingSearch = true;
    this.productSearchResults = [];
    this.currentProductPage = 0;
    this.barcodeService.searchProduct(query, 0, 10).pipe(takeUntil(this.destroy$)).subscribe({
      next: response => {
        this.totalProductResults = response.totalCount;
        this.totalProductPages = response.pageCount;
        this.productSearchResults = response.data.map(p => ({ ...p, barcodes: [], loadingBarcodes: true }));
        this.isLoadingSearch = false;
        if (!response.data.length) this.showToast('Товары не найдены', 'error');
        this.productSearchResults.forEach(p => this.loadProductBarcodes(p));
      },
      error: () => { this.isLoadingSearch = false; this.showToast('Ошибка при поиске товара', 'error'); }
    });
  }
  private loadProductBarcodes(product: ProductRow): void {
    this.barcodeService.getBarcodesByProduct(product.id, 0, 100).pipe(takeUntil(this.destroy$)).subscribe({
      next: r => { product.barcodes = r.data || []; product.loadingBarcodes = false; },
      error: () => { product.loadingBarcodes = false; this.showToast('Не удалось загрузить фасовки товара', 'error'); }
    });
  }
  changeProductPage(page: number): void {
    if (page < 0 || page >= this.totalProductPages) return;
    this.currentProductPage = page;
    this.isLoadingSearch = true;
    this.barcodeService.searchProduct(this.searchQuery.trim(), page, 10).pipe(takeUntil(this.destroy$)).subscribe({
      next: r => {
        this.productSearchResults = r.data.map(p => ({ ...p, barcodes: [], loadingBarcodes: true }));
        this.totalProductPages = r.pageCount; this.isLoadingSearch = false;
        this.productSearchResults.forEach(p => this.loadProductBarcodes(p));
      },
      error: () => { this.isLoadingSearch = false; this.showToast('Ошибка при загрузке страницы', 'error'); }
    });
  }
  startEdit(barcode: ProductBarcode): void {
    this.originalBarcode = { ...barcode };
    this.editingBarcode = { ...barcode, representationFrom1C: barcode.representationFrom1C ?? '' };
  }
  cancelEdit(): void { this.editingBarcode = null; this.originalBarcode = null; }
  saveBarcodeEdit(): void {
    if (!this.editingBarcode?.id || !this.originalBarcode) return;
    const b = this.editingBarcode, o = this.originalBarcode;
    const changes: Partial<ProductBarcode> = {};
    if (b.representationFrom1C !== o.representationFrom1C) changes.representationFrom1C = b.representationFrom1C ?? null;
    if (+b.coefficient !== +o.coefficient) changes.coefficient = +b.coefficient;
    if (b.measurementUnitId !== o.measurementUnitId) changes.measurementUnitId = b.measurementUnitId;
    if (!Object.keys(changes).length) { this.cancelEdit(); return; }
    this.barcodeService.updateBarcode(b.id, changes).pipe(takeUntil(this.destroy$)).subscribe({
      next: () => {
        const row = this.productSearchResults.find(p => p.id === b.productInstanceId);
        const index = row?.barcodes.findIndex(x => x.id === b.id) ?? -1;
        if (row && index >= 0) row.barcodes[index] = { ...b, measurementUnit: this.measurementUnits.find(u => u.id === b.measurementUnitId) };
        this.cancelEdit(); this.showToast('Фасовка обновлена', 'success');
      },
      error: () => this.showToast('Не удалось обновить фасовку', 'error')
    });
  }
  startAdd(product: ProductRow): void {
    product.adding = true;
    this.drafts[product.id] = {
      barCode: this.generateBarcode(), representationFrom1C: '', coefficient: 1,
      measurementUnitId: product.baseMeasurementUnit?.id || this.measurementUnits[0]?.id || ''
    };
  }
  cancelAdd(product: ProductRow): void { product.adding = false; delete this.drafts[product.id]; }
  addBarcode(product: ProductRow): void {
    const d = this.drafts[product.id];
    if (!d || !d.barCode?.trim() || !d.measurementUnitId || !(+d.coefficient > 0)) {
      this.showToast('Заполните штрихкод, коэффициент и единицу измерения', 'error'); return;
    }
    this.isSaving = true;
    this.barcodeService.createBarcode({
      barCode: d.barCode.trim(), representationFrom1C: d.representationFrom1C || undefined,
      coefficient: +d.coefficient, productInstanceId: product.id, measurementUnitId: d.measurementUnitId,
      measurementUnit: this.measurementUnits.find(u => u.id === d.measurementUnitId), comment: 'сайт пакетон'
    } as Omit<ProductBarcode, 'id'>).pipe(takeUntil(this.destroy$)).subscribe({
      next: () => {
        this.isSaving = false; product.adding = false; delete this.drafts[product.id];
        this.showToast('Фасовка добавлена', 'success'); this.loadProductBarcodes(product);
      },
      error: () => { this.isSaving = false; this.showToast('Не удалось добавить фасовку', 'error'); }
    });
  }
  deleteBarcode(product: ProductRow, barcode: ProductBarcode): void {
    if (!barcode.id) return;
    const restore = !!barcode.isDeleted;
    if (!confirm(`Вы действительно хотите ${restore ? 'восстановить' : 'удалить'} штрихкод «${barcode.barCode}»?`)) return;
    this.barcodeService.softDeleteBarcode(barcode.id, !restore).pipe(takeUntil(this.destroy$)).subscribe({
      next: () => { barcode.isDeleted = !restore; this.showToast(restore ? 'Фасовка восстановлена' : 'Фасовка удалена', 'success'); },
      error: () => this.showToast('Не удалось изменить статус фасовки', 'error')
    });
  }
  getMeasurementUnitName(id: string): string {
    const u = this.measurementUnits.find(x => x.id === id); return u ? `${u.name || u.shortName} (${u.shortName})` : '—';
  }
  formatPrice(price: number | null | undefined): string {
    return price == null ? '—' : new Intl.NumberFormat('ru-RU', { style: 'currency', currency: 'RUB' }).format(price);
  }
  handleImageError(event: Event): void { (event.target as HTMLImageElement).style.visibility = 'hidden'; }
  clearSearch(): void { this.searchQuery = ''; this.productSearchResults = []; this.searchInput?.nativeElement?.focus(); }
  private generateBarcode(): string {
    const base = `23${Date.now().toString().slice(-6)}${Math.floor(Math.random() * 10000).toString().padStart(4, '0')}`;
    return base;
  }
  private showToast(message: string, type: 'success' | 'error'): void {
    this.toastMessage = message; this.toastType = type;
    setTimeout(() => this.toastMessage = null, 3000);
  }
}
